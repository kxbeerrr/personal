import React, { useState } from 'react';
import { SpotifyOffer } from './components/SpotifyOffer';
import { PrankReveal } from './components/PrankReveal';

function App() {
  const [claimed, setClaimed] = useState(false);

  return (
    <div className="min-h-screen bg-black text-white">
      {!claimed ? (
        <SpotifyOffer onClaim={() => setClaimed(true)} />
      ) : (
        <PrankReveal />
      )}
    </div>
  );
}

export default App;