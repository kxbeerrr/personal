export interface TextDrop {
  id: number;
  x: number;
  y: number;
  text: string;
}

export interface GlitchTextProps {
  text: string;
  className?: string;
}