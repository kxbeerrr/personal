import React from 'react';
import { Gift, Music2 } from 'lucide-react';
import { COLORS } from '../constants/theme';

interface SpotifyOfferProps {
  onClaim: () => void;
}

export function SpotifyOffer({ onClaim }: SpotifyOfferProps) {
  return (
    <div className="container mx-auto px-4 py-16 flex flex-col items-center">
      <div className="mb-8" style={{ color: COLORS.spotify.primary }}>
        <Music2 size={64} className="animate-pulse" />
      </div>
      <h1 
        className="text-4xl md:text-6xl font-bold text-center mb-6"
        style={{ color: COLORS.spotify.primary }}
      >
        Spotify Premium Gift
      </h1>
      <p className="text-xl md:text-2xl text-center mb-8 text-gray-300">
        Exclusive offer from kxbeerrr
      </p>
      <div 
        className="p-8 rounded-lg shadow-xl max-w-md w-full"
        style={{ 
          background: `linear-gradient(135deg, ${COLORS.spotify.primary}, ${COLORS.spotify.light})`,
          boxShadow: `0 0 20px ${COLORS.spotify.primary}`
        }}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Premium Individual</h2>
            <p className="text-sm text-white/75">Free for 6 months</p>
          </div>
          <Gift size={32} className="text-white" />
        </div>
        <ul className="mb-6 space-y-2 text-white">
          <li className="flex items-center">✓ Ad-free music listening</li>
          <li className="flex items-center">✓ Download to listen offline</li>
          <li className="flex items-center">✓ High quality audio</li>
        </ul>
        <button
          onClick={onClaim}
          className="w-full bg-black text-white py-3 rounded-full font-bold hover:scale-105 transition-transform"
        >
          Claim Now
        </button>
      </div>
    </div>
  );
}