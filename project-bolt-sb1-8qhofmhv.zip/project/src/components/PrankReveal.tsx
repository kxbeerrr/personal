import React from 'react';
import { RainingText } from './RainingText';
import { GlitchBox } from './GlitchBox';
import { GlitchText } from './GlitchText';
import { ParticleBackground } from './ParticleBackground';
import { ShootingStars } from './ShootingStars';

export function PrankReveal() {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <ParticleBackground />
      <ShootingStars />
      <RainingText />
      <GlitchBox className="z-10">
        <GlitchText 
          text="chii yrr maharani Ji"
          className="text-4xl md:text-6xl font-bold mb-4 text-center"
        />
        <GlitchText 
          text="You've been pranked! 🎉"
          className="text-center text-lg"
        />
      </GlitchBox>
    </div>
  );
}