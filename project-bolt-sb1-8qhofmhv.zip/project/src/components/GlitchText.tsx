import React from 'react';
import { COLORS } from '../constants/theme';
import { GlitchTextProps } from '../types/types';

export function GlitchText({ text, className = '' }: GlitchTextProps) {
  return (
    <div className={`glitch-container relative ${className}`} data-text={text}>
      <span className="absolute inset-0 glitch-layer glitch-layer-1">
        {text}
      </span>
      <span className="absolute inset-0 glitch-layer glitch-layer-2">
        {text}
      </span>
      <span className="absolute inset-0 glitch-layer glitch-layer-3">
        {text}
      </span>
      <span className="relative glitch-main-text">
        {text}
      </span>
    </div>
  );
}
