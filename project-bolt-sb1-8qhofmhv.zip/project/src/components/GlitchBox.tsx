import React, { ReactNode } from 'react';
import { COLORS } from '../constants/theme';

interface GlitchBoxProps {
  children: ReactNode;
  className?: string;
}

export function GlitchBox({ children, className = '' }: GlitchBoxProps) {
  return (
    <div className="relative">
      {/* Glitch layers */}
      <div className="absolute inset-0 glitch-1">
        <div 
          className={`backdrop-blur-sm p-8 rounded-xl ${className}`}
          style={{ 
            background: 'rgba(0, 0, 0, 0.7)',
            border: `2px solid ${COLORS.glitch.primary}`,
            boxShadow: `0 0 20px ${COLORS.glitch.primary}`,
            animation: 'move-border 2s ease-in-out infinite, glow 1.5s ease-in-out infinite alternate, shake 0.5s ease-in-out infinite',
          }}
        />
      </div>
      <div className="absolute inset-0 glitch-2">
        <div 
          className={`backdrop-blur-sm p-8 rounded-xl ${className}`}
          style={{ 
            background: 'rgba(0, 0, 0, 0.7)',
            border: `2px solid ${COLORS.glitch.secondary}`,
            boxShadow: `0 0 20px ${COLORS.glitch.secondary}`,
            animation: 'move-border 2s ease-in-out infinite, glow 1.5s ease-in-out infinite alternate, shake 0.5s ease-in-out infinite',
          }}
        />
      </div>
      {/* Main content */}
      <div 
        className={`backdrop-blur-sm p-8 rounded-xl relative ${className}`}
        style={{ 
          background: 'rgba(0, 0, 0, 0.7)',
          border: `2px solid ${COLORS.glitch.primary}`,
          boxShadow: `0 0 20px ${COLORS.glitch.glow}`,
          animation: 'move-border 2s ease-in-out infinite, glow 1.5s ease-in-out infinite alternate, shake 0.5s ease-in-out infinite',
        }}
      >
        {children}
      </div>
    </div>
  );
}
