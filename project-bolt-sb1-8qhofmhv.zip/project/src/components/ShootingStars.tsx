import React, { useEffect, useRef } from 'react';
import { SHOOTING_STAR_CONFIG } from '../constants/animation';
import { COLORS } from '../constants/theme';

interface Star {
  x: number;
  y: number;
  speedX: number;
  speedY: number;
  trail: Array<{ x: number; y: number }>;
  radius: number; // Added a radius for size control
}

export function ShootingStars() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const stars: Star[] = [];

    function createStar(): Star {
      const angle = Math.random() * Math.PI / 4 + Math.PI / 4; // 45-90 degrees
      const speed = SHOOTING_STAR_CONFIG.MIN_SPEED + 
        Math.random() * (SHOOTING_STAR_CONFIG.MAX_SPEED - SHOOTING_STAR_CONFIG.MIN_SPEED);
      
      // Increased the star size by setting a random radius
      const radius = Math.random() * 2 + 3; // Random radius between 3 and 5

      return {
        x: Math.random() * canvas.width,
        y: 0,
        speedX: Math.cos(angle) * speed,
        speedY: Math.sin(angle) * speed,
        trail: [],
        radius: radius, // Store the radius in the star object
      };
    }

    function updateStar(star: Star) {
      star.trail.unshift({ x: star.x, y: star.y });
      if (star.trail.length > SHOOTING_STAR_CONFIG.TRAIL_LENGTH) {
        star.trail.pop();
      }

      star.x += star.speedX;
      star.y += star.speedY;

      return star.x < canvas.width && star.y < canvas.height;
    }

    function drawStar(star: Star) {
      if (!ctx) return;

      ctx.beginPath();
      ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2); // Draw the star as a circle using radius
      ctx.fillStyle = `rgba(255, 255, 255, 1)`; // White color for the star
      ctx.fill();

      // Draw the trail with a fading effect
      star.trail.forEach((pos, index) => {
        const alpha = 1 - index / star.trail.length;
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`; // White trail color with fading
        ctx.lineWidth = star.radius * 0.2; // Trail width based on star radius
        ctx.lineTo(pos.x, pos.y);
      });

      ctx.stroke();
      ctx.closePath();
    }

    function animate() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update and draw existing stars
      for (let i = stars.length - 1; i >= 0; i--) {
        const isVisible = updateStar(stars[i]);
        if (!isVisible) {
          stars.splice(i, 1);
        } else {
          drawStar(stars[i]);
        }
      }

      requestAnimationFrame(animate);
    }

    // Spawn new stars periodically
    const spawnInterval = setInterval(() => {
      if (stars.length < SHOOTING_STAR_CONFIG.COUNT) {
        stars.push(createStar());
      }
    }, SHOOTING_STAR_CONFIG.SPAWN_INTERVAL);

    animate();

    const handleResize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      clearInterval(spawnInterval);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
}
