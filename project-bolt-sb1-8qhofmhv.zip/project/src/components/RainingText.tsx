import React from 'react';
import { useRainAnimation } from '../hooks/useRainAnimation';
import { RAIN_CONFIG } from '../constants/animation';

export function RainingText() {
  const drops = useRainAnimation();

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {drops.slice(0, 50).map((drop) => {  // Limit the number of drops for less density
        const randomGlowColor = RAIN_CONFIG.GLOW_COLORS[Math.floor(Math.random() * RAIN_CONFIG.GLOW_COLORS.length)];

        return (
          <div
            key={drop.id}
            className="absolute font-bold text-lg animate-fall"
            style={{
              left: `${drop.x}px`,
              top: `${-50}px`,  // Start from above the screen
              color: randomGlowColor, // Use random glow color
              animation: `fall 4s ease-in infinite`, // Simpler falling animation
            }}
          >
            {drop.text}
          </div>
        );
      })}
    </div>
  );
}


