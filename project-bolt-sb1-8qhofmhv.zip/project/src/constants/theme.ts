export const COLORS = {
  spotify: {
    primary: '#1DB954',
    dark: '#1ed760',
    light: '#1fdf64',
  },
  glitch: {
    primary: '#ff69b4',
    secondary: '#ff1493',
    glow: '#ff69b4'
  }
} as const;