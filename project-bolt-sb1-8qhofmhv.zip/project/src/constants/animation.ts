export const RAIN_CONFIG = {
  DROP_SPEED: 8,
  SPAWN_INTERVAL: 30,
  ROTATION_RANGE: 30,
  INITIAL_Y: -20,
  GLOW_COLORS: ['#ff69b4', '#1DB954', '#ff1493']
} as const;

export const PARTICLE_CONFIG = {
  COUNT: 50,
  MAX_SIZE: 3
} as const;

export const SHOOTING_STAR_CONFIG = {
  COUNT: 3,
  MIN_SPEED: 4,
  MAX_SPEED: 8,
  TRAIL_LENGTH: 20,
  SPAWN_INTERVAL: 2000
} as const;

export const TEXTS = ['chii', 'chii yrr'] as const;