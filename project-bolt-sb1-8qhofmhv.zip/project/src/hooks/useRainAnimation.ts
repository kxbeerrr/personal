import { useState, useEffect } from 'react';
import { TextDrop } from '../types/types';
import { RAIN_CONFIG, TEXTS } from '../constants/animation';

const getRandomText = () => TEXTS[Math.floor(Math.random() * TEXTS.length)];
const getRandomX = () => Math.random() * window.innerWidth;

export function useRainAnimation() {
  const [drops, setDrops] = useState<TextDrop[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setDrops((prevDrops) => {
        const filteredDrops = prevDrops.filter(
          (drop) => drop.y < window.innerHeight
        );
        
        const newDrop = {
          id: Date.now(),
          x: getRandomX(),
          y: RAIN_CONFIG.INITIAL_Y,
          text: getRandomText()
        };

        return [...filteredDrops, newDrop].map(drop => ({
          ...drop,
          y: drop.y + RAIN_CONFIG.DROP_SPEED
        }));
      });
    }, RAIN_CONFIG.SPAWN_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  return drops;
}